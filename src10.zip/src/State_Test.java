import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * test class for state
 */
public class State_Test {
    private State finalSt, startSt, finalStartSt, normalSt;

    /**
     * set up
     * @throws Exception no
     */
    @Before
    public void setUp(){
        finalSt = new State(true, false);
        startSt = new State(false, true);
        finalStartSt = new State(true, true);
        normalSt = new State(false, false);
    }

    /**
     * test to string
     */
    @Test
    public void testToString () {
        assertEquals(finalSt.toString(), "q" + finalSt.getIndex());
    }

    /**
     * test is final
     */
    @Test
    public void isFinal() {
        assertTrue(finalSt.isFinal());
        assertTrue(finalStartSt.isFinal());
        assertFalse(startSt.isFinal());
        assertFalse(normalSt.isFinal());
    }

    /**
     * test isInitial
     */
    @Test
    public void isInitial() {
        assertTrue(startSt.isInitial());
        assertTrue(finalStartSt.isInitial());
        assertFalse(finalSt.isInitial());
        assertFalse(normalSt.isInitial());
    }

    /**
     * test setFinal
     */
    @Test
    public void setFinal() {
        normalSt.setFinal(true);
        assertTrue(normalSt.isFinal());
    }

    /**
     * test setInitial
     */
    @Test
    public void setInitial() {
        normalSt.setInitial(true);
        assertTrue(normalSt.isInitial());
    }

    /**
     * test addTransition
     */
    @Test
    public void addTransition() {
        normalSt.addTransition('a', finalSt);
        assertEquals(normalSt.transitions.size(), 1);
    }

    /**
     * test getIndex
     */
    @Test
    public void getIndex() {
        assertEquals(normalSt.getIndex(), normalSt.hashCode());
    }

    /**
     * test getTransitionBySymbol
     */
    @Test
    public void getTransitionBySymbol() {
        normalSt.addTransition('a', finalSt);
        assertEquals(normalSt.getTransitionBySymbol('a').size(), 1);
    }

    /**
     * test equals
     */
    @Test
    public void equalsTest() {
        assertEquals(normalSt, normalSt);
        assertNotEquals(normalSt, startSt);
        assertNotEquals(normalSt, null);

    }
}