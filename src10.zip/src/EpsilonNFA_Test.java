import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * test class for epsilon nfa
 */
public class EpsilonNFA_Test {

    private EpsilonNFA nfa;
    private State finalSt, startSt;

    /**
     * setup
     * @throws Exception no
     */
    @Before
    public void setUp() throws Exception {
        nfa = new EpsilonNFA();
        finalSt = new State(true, false);
        startSt = new State(false, true);
        nfa.addState(finalSt);
        nfa.addState(startSt);

    }

    /**
     * test add symbol
     */
    @Test
    public void addSymbol() {
        assertFalse(nfa.symbolSet.contains('a'));
        nfa.addSymbol('a');
        assertTrue(nfa.symbolSet.contains('a'));
    }

    /**
     * test add state
     */
    @Test
    public void addState() {

        assertFalse(nfa.F.isEmpty());
        assertFalse(nfa.Q0.isEmpty());
        assertEquals(nfa.Q.size(), 2);
    }

    /**
     * test getInitialState
     */
    @Test
    public void getInitialState() {
        assertEquals(startSt, nfa.getInitialState());

        nfa = new EpsilonNFA();
        assertNull(nfa.getInitialState());
    }

    /**
     * test getFinalState
     */
    @Test
    public void getFinalState() {
        assertEquals(finalSt, nfa.getFinalState());
        nfa = new EpsilonNFA();
        assertNull(nfa.getInitialState());
    }

    /**
     * test mergeOtherEpsilonNFA
     */
    @Test
    public void mergeOtherEpsilonNFA() {
        EpsilonNFA nfa1 = new EpsilonNFA();
        nfa1.mergeOtherEpsilonNFA(nfa);
        assertEquals(2, nfa1.Q.size());
    }

    /**
     * test printTransitionTable
     */
    @Test
    public void printTransitionTable() {
        RegularExpression exp = new RegularExpression(RegularExpression.parseReg("(ab)*|c+"));
        nfa = exp.convert2NFA();
        nfa.printTransitionTable();
    }

    /**
     * test matchPattern
     */
    @Test
    public void matchPattern() {
        RegularExpression exp = new RegularExpression(RegularExpression.parseReg("(ab)*|c+"));
        nfa = exp.convert2NFA();
        assertTrue(nfa.matchPattern("c"));
        assertTrue(nfa.matchPattern("ab"));
        assertTrue(nfa.matchPattern("abab"));
        assertTrue(nfa.matchPattern("cccc"));
        assertTrue(nfa.matchPattern(""));

        assertFalse(nfa.matchPattern("abc"));
        assertFalse(nfa.matchPattern("acb"));
        assertFalse(nfa.matchPattern("abc"));
        assertFalse(nfa.matchPattern("abb"));
    }
}