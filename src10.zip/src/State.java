import java.util.ArrayList;
import java.util.HashSet;

/**
 * this class represent a state in epsilon-NFA
 */
public class State {

    /**
     * record the index in the system
     */
    private static int totalState = 0;

    /**
     * indicator of final state
     */
    boolean isFinal;

    /**
     * indicator of start state
     */
    boolean isInitial;

    /**
     * index of the state
     */
    int index;

    /**
     * transition list
     */
    ArrayList<Transition> transitions = new ArrayList<>();

    /**
     * constructor
     * @param isFinal is final
     * @param isInitial is initial
     */
    public State(boolean isFinal, boolean isInitial) {
        this.isFinal = isFinal;
        this.isInitial = isInitial;
        this.index = totalState;
        totalState ++;
    }

    /**
     *
     * @return is final
     */
    public boolean isFinal() {
        return isFinal;
    }

    /**
     *
     * @return is initial
     */
    public boolean isInitial() {
        return isInitial;
    }

    /**
     * set isFinal
     * @param aFinal new value to be set
     */
    public void setFinal(boolean aFinal) {
        isFinal = aFinal;
    }

    /**
     * set isInitial
     * @param initial new value
     */
    public void setInitial(boolean initial) {
        isInitial = initial;
    }

    /**
     * add new transition to the nfa
     * @param symbol symbol of the transition
     * @param next next state of the transition
     */
    public void addTransition(char symbol, State next) {
        transitions.add(new Transition(symbol, next));
    }

    /**
     * get the index
     * @return index
     */
    public int getIndex() {
        return index;
    }

    /**
     * return the list of all next states if given the
     * symbol
     * @param symbol symbol
     * @return  the list of all next states
     */
    public ArrayList<State> getTransitionBySymbol(char symbol) {
        ArrayList<State> result = new ArrayList<>();
        for (Transition t: transitions) {
            if (t.getSymbol() == symbol) {
                result.add(t.getNextState());
;            }
        }
        return result;
    }

    /**
     * use q + {index} as the string representation
     * @return formatted string
     */
    @Override
    public String toString() {

        return "q" + index;

    }

    /**
     * equals
     * @param o other object
     * @return true if index is the same
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        State state = (State) o;
        return getIndex() == state.getIndex();
    }

    /**
     * use index as the hash code
     * @return index
     */
    @Override
    public int hashCode() {
        return getIndex();
    }

    /**
     * match the sample string from start index
     * @param sample sample to be matched
     * @param startIndex the start index
     * @param visitedEpsilon the state set only through EPSILON transitions
     * @return the match result
     */
    public boolean match (String sample, int startIndex, HashSet<State> visitedEpsilon) {
        // reach the last one
        if (startIndex == sample.length()) {
            if (this.isFinal())
                return true;

            // then consider the epsilon symbol
            visitedEpsilon.add(this);
            for (Transition t: transitions) {
                if (Transition.EPSILON == t.getSymbol()) {
                    State next = t.getNextState();
                    if (next.match(sample, startIndex, visitedEpsilon)) {
                        return true;
                    }
                }
            }
            visitedEpsilon.remove(this);

            return false;
        }

        // reach a visited state, quickly quit
        if (visitedEpsilon.contains(this)) return false;

        // first consider the non-epsilon symbol
        char c = sample.charAt(startIndex);
        for (Transition t: transitions) {
            if (c == t.getSymbol()) {
                State next = t.getNextState();
                if (next.match(sample, startIndex + 1, new HashSet<>())) {
                    return true;
                }
            }
        }

        // then consider the epsilon symbol
        visitedEpsilon.add(this);
        for (Transition t: transitions) {
            if (Transition.EPSILON == t.getSymbol()) {
                State next = t.getNextState();
                if (next.match(sample, startIndex, visitedEpsilon)) {
                    return true;
                }
            }
        }
        visitedEpsilon.remove(this);

        return false;


    }
}
