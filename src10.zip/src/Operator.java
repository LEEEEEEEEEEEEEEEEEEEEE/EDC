/**
 * enum operator: regex expression
 */
public enum Operator {

    /**
     * sequence
     */
    SEQ,

    /**
     * alternative operator
     */
    ALTER,

    /**
     * Kleene Plus
     */
    PLUS,

    /**
     * Kleene star
     */
    STAR
}
