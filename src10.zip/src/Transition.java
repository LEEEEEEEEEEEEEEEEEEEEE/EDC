/**
 * Transition is a class consist of a symbol and a destination state
 * it is used as the transition from one state to another
 */

public class Transition {

    /**
     * use \0 as epsilon
     */
    public static final char EPSILON = '\0';

    /**
     * symbol
     */
    char symbol;

    /**
     * next state
     */
    State nextState;

    /**
     * the constructor
     * @param symbol symbol
     * @param nextState next state
     */
    public Transition(char symbol, State nextState) {
        this.symbol = symbol;
        this.nextState = nextState;
    }

    /**
     * getter of symbol
     * @return symbol
     */
    public char getSymbol() {
        return symbol;
    }

    /**
     * getter of next state
     * @return next state
     */
    public State getNextState() {
        return nextState;
    }
}
