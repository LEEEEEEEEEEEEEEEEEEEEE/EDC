import org.junit.Test;

import static org.junit.Assert.*;

/**
 * test class for SymbolNode
 */
public class SymbolNode_Test {

    /**
     * test toString
     */
    @Test
    public void testToString() {
        assertEquals(new SymbolNode('a').toString(), "a");

    }

    /**
     * test convert2NFA
     */
    @Test
    public void convert2NFA() {
        SymbolNode node = new SymbolNode('a');
        EpsilonNFA nfa = node.convert2NFA();
        assertTrue(nfa.symbolSet.contains('a'));
        assertEquals(2, nfa.Q.size());
    }
}