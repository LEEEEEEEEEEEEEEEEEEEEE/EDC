/**
 * reg node contains only symbol
 */
public class SymbolNode extends RegNode {

    /**
     * the symbol
     */
    char symbol;

    /**
     * constructor
     * @param c symbol
     */
    public SymbolNode(char c) {
        symbol = c;
    }

    /**
     * to string
     * @return string
     */
    @Override
    public String toString() {
        return String.valueOf(symbol);
    }

    /**
     * convert to NFA
     * @return nfa
     */
    @Override
    public EpsilonNFA convert2NFA() {
        EpsilonNFA nfa = new EpsilonNFA();
        nfa.addSymbol(symbol);
        State start = new State(false, true);
        State end = new State(true, false);
        start.addTransition(symbol, end);
        nfa.addState(start);
        nfa.addState(end);
        return nfa;
    }
}
