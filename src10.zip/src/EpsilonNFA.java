import java.util.ArrayList;
import java.util.HashSet;

/**
 * this class represent an epsilon-NFA
 * 5 element tuple,
 * the transition function is store in state class
 */

public class EpsilonNFA {


    /**
     * state set
     */
    HashSet<State> Q = new HashSet<>();

    /**
     * symbol set
     */
    HashSet<Character> symbolSet = new HashSet<>();

    /**
     * initial state
     */
    HashSet<State> Q0 = new HashSet<>();

    /**
     * final state
     */
    HashSet<State> F = new HashSet<>();

    /**
     * add symbol to symbol set
     * @param symbol the symbol to be added
     */
    public void addSymbol(char symbol) {
        symbolSet.add(symbol);
    }

    /**
     * add a new state to the state sets
     * @param state the state to be added
     */
    public void addState(State state) {
        Q.add(state);
        if (state.isFinal()) {
            F.add(state);
        }

        if (state.isInitial()) {
            Q0.add(state);
        }
    }

    /**
     * get the first initial state
     * @return the first initial state
     */
    public State getInitialState() {


        for (State st: Q0) {
            return st;
        }
        return null;
    }

    /**
     * get the first final state
     * @return the first final state
     */
    public State getFinalState() {


        for (State st: F) {
            return st;
        }
        return null;
    }

    /**
     * merge other nfa to this
     * @param other other nfa
     */
    public void mergeOtherEpsilonNFA(EpsilonNFA other) {
        Q.addAll(other.Q);
        symbolSet.addAll(other.symbolSet);
    }

    /**
     * print the transition table
     */
    public void printTransitionTable() {
        for (Character c: symbolSet) {
            System.out.print("\t\t" + c + "|");
        }
        System.out.println("\tEPSILON");
        for (State s: Q) {
            if (s.isInitial()) {
                System.out.print(">");
            } else {
                System.out.print(" ");
            }
            if (s.isFinal()) {
                System.out.print("*");
            } else {
                System.out.print(" ");
            }
            System.out.print(s + "\t");

            for (Character c: symbolSet) {
                ArrayList<State> next = s.getTransitionBySymbol(c);
                System.out.print(c + ":" + next);
                System.out.print("\t");
            }

            ArrayList<State> next = s.getTransitionBySymbol(Transition.EPSILON);
            System.out.println("Epsilon:" + next);
        }
        System.out.println();
    }

    /**
     * match the sample string with the pattern represented
     * by this nfa
     * @param sample the sample to be matched
     * @return true only if match
     */
    public boolean matchPattern(String sample) {

        State start = getInitialState();

        return start.match(sample, 0, new HashSet<>());
    }
}
