import java.util.ArrayList;

/**
 * a regex node with operator
 */
public class OperatorNode extends RegNode{

    /**
     * the operator
     */
    Operator op;

    /**
     * the children nodes for the operator
     */
    ArrayList<RegNode> nodes = new ArrayList<>();

    /**
     * constructor
     * @param op the operator
     */
    public OperatorNode(Operator op) {
        this.op = op;
    }

    /**
     * add a reg node as child
     * @param node the node to be added
     */
    public void addNode(RegNode node) {
        nodes.add(node);
    }

    /**
     * return a string representation
     * @return a string representation
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append('(');
        switch (op) {
            case SEQ:
                for (RegNode node: nodes) {
                    sb.append(node.toString());
                }
                break;
            case PLUS:
                sb.append(nodes.get(0).toString());
                sb.append('+');
                break;
            case STAR:
                sb.append(nodes.get(0).toString());
                sb.append('*');
                break;
            case ALTER:
                sb.append(nodes.get(0).toString());
                sb.append(" | ");
                sb.append(nodes.get(1).toString());
                break;

        }
        sb.append(')');
        return sb.toString();
    }

    /**
     * convert the node to a nfa
     * @return nfa
     */
    @Override
    public EpsilonNFA convert2NFA() {
        EpsilonNFA nfa = new EpsilonNFA();
        if (op == Operator.PLUS) {
            EpsilonNFA nfa1 = nodes.get(0).convert2NFA();
            State nfa1Start = nfa1.getInitialState();
            nfa1Start.setInitial(false);

            State nfa1End = nfa1.getFinalState();
            nfa1End.setFinal(false);

            State start = new State(false, true);
            State end = new State(true, false);

            start.addTransition(Transition.EPSILON, nfa1Start);
            nfa1End.addTransition(Transition.EPSILON, end);
            end.addTransition(Transition.EPSILON, nfa1Start);

            nfa.addState(start);
            nfa.addState(end);
            nfa.mergeOtherEpsilonNFA(nfa1);

        } else if (op == Operator.STAR) {
            EpsilonNFA nfa1 = nodes.get(0).convert2NFA();
            State nfa1Start = nfa1.getInitialState();
            nfa1Start.setInitial(false);

            State nfa1End = nfa1.getFinalState();
            nfa1End.setFinal(false);

            State start = new State(true, true);
            start.addTransition(Transition.EPSILON, nfa1Start);
            nfa1End.addTransition(Transition.EPSILON, start);
            nfa.addState(start);
            nfa.mergeOtherEpsilonNFA(nfa1);

        } else if (op == Operator.ALTER) {
            EpsilonNFA nfa1 = nodes.get(0).convert2NFA();
            State nfa1Start = nfa1.getInitialState();
            State nfa1End = nfa1.getFinalState();
            nfa1Start.setInitial(false);
            nfa1End.setFinal(false);

            EpsilonNFA nfa2 = nodes.get(1).convert2NFA();
            State nfa2Start = nfa2.getInitialState();
            State nfa2End = nfa2.getFinalState();
            nfa2Start.setInitial(false);
            nfa2End.setFinal(false);

            State start = new State(false, true);
            State end = new State(true, false);

            start.addTransition(Transition.EPSILON, nfa1Start);
            start.addTransition(Transition.EPSILON, nfa2Start);

            nfa1End.addTransition(Transition.EPSILON, end);
            nfa2End.addTransition(Transition.EPSILON, end);




            nfa.addState(start);
            nfa.addState(end);
            nfa.mergeOtherEpsilonNFA(nfa1);
            nfa.mergeOtherEpsilonNFA(nfa2);

        } else {
            // by default, op SEQ
            State start = null;
            State end = null;

            for (RegNode node : nodes) {
                EpsilonNFA nfaTemp = node.convert2NFA();
                State tempStart = nfaTemp.getInitialState();
                State tempEnd = nfaTemp.getFinalState();
                if (start == null) {
                    start = tempStart;
                } else {
                    tempStart.setInitial(false);
                }
                if (end != null) {
                    end.setFinal(false);
                    end.addTransition(Transition.EPSILON, tempStart);
                }
                end = tempEnd;
                nfa.mergeOtherEpsilonNFA(nfaTemp);
            }
            nfa.addState(start);
            nfa.addState(end);
        }
        return nfa;
    }
}
