import org.junit.Test;

import static org.junit.Assert.*;

/**
 * test class for operator node class
 */
public class OperatorNode_Test {

    /**
     * test toString
     */
    @Test
    public void testToString() {
        OperatorNode node = (OperatorNode) RegularExpression.parseReg("(ab)*|c+");
        assertEquals(node.op, Operator.ALTER);
        String result = node.toString();
        assertEquals("(((ab)*) | (c+))", result);
    }

    /**
     * test convert2NFA
     */
    @Test
    public void convert2NFA() {
        OperatorNode node = (OperatorNode) RegularExpression.parseReg("a|b");
        assertEquals(node.op, Operator.ALTER);
        EpsilonNFA nfa = node.convert2NFA();
        assertTrue(nfa.symbolSet.contains('a'));
        assertTrue(nfa.symbolSet.contains('b'));
        assertFalse(nfa.symbolSet.contains('c'));

        node = (OperatorNode) RegularExpression.parseReg("a*");
        assertEquals(node.op, Operator.STAR);
        nfa = node.convert2NFA();
        assertEquals(nfa.Q.size(), 3);

        node = (OperatorNode) RegularExpression.parseReg("a+");
        assertEquals(node.op, Operator.PLUS);
        nfa = node.convert2NFA();
        assertEquals(nfa.Q.size(), 4);

        node = (OperatorNode) RegularExpression.parseReg("ab");
        assertEquals(node.op, Operator.SEQ);
        nfa = node.convert2NFA();
        assertEquals(nfa.Q.size(), 4);

    }
}