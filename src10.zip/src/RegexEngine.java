

import java.util.Scanner;

/**
 * RegexEngine main class
 */
public class RegexEngine {

    /**
     * main, accept one extra argument "-v"
     * @param args arguments
     */
    public static void main(String[] args) {
        boolean verbose = args.length > 0 && args[0].equals("-v");

        Scanner sc = new Scanner(System.in);

        RegularExpression regExp;
        EpsilonNFA nfa = null;
        if (sc.hasNextLine()) {
            String line = sc.nextLine();
            try {
                RegNode root = RegularExpression.parseReg(line);
                regExp = new RegularExpression(root);
                nfa = regExp.convert2NFA();
                if (verbose) {
                    nfa.printTransitionTable();
                }
                System.out.println("ready");

            } catch (Exception e) {
                System.out.println(e.getMessage());
                return;
            }
        }

        while (true) {
            if (sc.hasNextLine()) {
                String sample = sc.nextLine();
                if (nfa.matchPattern(sample)) {
                    System.out.println("true");
                } else {
                    System.out.println("false");
                }

                if (verbose) {
                    for (int i = 0; i < sample.length(); i++) {
                        char c = sample.charAt(i);
                        System.out.println(c);
                        if (nfa.matchPattern(sample.substring(0, i+1))) {
                            System.out.println("true");
                        } else {
                            System.out.println("false");
                        }

                    }
                    System.out.println();
                }
            } else {
                return;
            }

        }

    }
}
