import java.util.ArrayList;
import java.util.HashSet;

/**
 * a wrapping class using reg node to represent a
 * regular expression
 */
public class RegularExpression {

    /**
     * root node of the regular expression node tree
     */
    RegNode root = null;

    /**
     * constructor
     * @param root the root
     */
    public RegularExpression(RegNode root) {
        this.root = root;
    }


    /**
     * call regnode's convert2NFA
     * @return nfa
     */
    public EpsilonNFA convert2NFA() {
        return root.convert2NFA();
    }

    /**
     * return true if char c is a letter or digit
     * @param c char
     * @return true if char c is a letter or digit
     */
    public static boolean isSymbol(char c) {
        return Character.isLetterOrDigit(c);
    }

    /**
     * parse regular
     * @param string string rep of a regexp
     * @return the regnode instance
     */
    public static RegNode parseReg(String string) {

        ArrayList<RegNode> nodes = new ArrayList<>();
        int i = 0;
        while (i < string.length()) {
            char c = string.charAt(i);
            if (isSymbol(c)) {
                nodes.add(new SymbolNode(c));
                i ++;
            } else if (c == '+') {
                if (nodes.isEmpty()) {
                    throw new IllegalArgumentException("Regular expression start with +");
                }
                OperatorNode node = new OperatorNode(Operator.PLUS);
                node.addNode(nodes.get(nodes.size() - 1));
                nodes.set(nodes.size() - 1, node);
                i++;
            } else if (c == '*') {
                if (nodes.isEmpty()) {
                    throw new IllegalArgumentException("Regular expression start with *");
                }
                OperatorNode node = new OperatorNode(Operator.STAR);
                node.addNode(nodes.get(nodes.size() - 1));
                nodes.set(nodes.size() - 1, node);
                i++;
            } else if (c == '|') {
                RegNode nextNode = parseReg(string.substring(i+1));
                OperatorNode node = new OperatorNode(Operator.ALTER);
                RegNode prev = null;
                if (nodes.size() > 1) {
                    prev = new OperatorNode(Operator.SEQ);
                    for (RegNode regNode : nodes) {
                        ((OperatorNode) prev).addNode(regNode);
                    }
                } else if (nodes.size() == 1) {
                    prev = nodes.get(0);
                } else {
                    throw new IllegalArgumentException("ALTER operator given but nothing before");
                }

                node.addNode(prev);
                node.addNode(nextNode);
                return node;
            } else if (c == '(') {
                int nextIndex = string.indexOf(')', i);
                if (nextIndex == -1) {
                    throw new IllegalArgumentException("Regular expression () should be closed");
                }
                RegNode node = parseReg(string.substring(i + 1, nextIndex));
                nodes.add(node);
                i = nextIndex + 1;

            } else if (Character.isSpaceChar(c)) {
                // we treat space in regular expression as no sense
                i++;

            } else {
                throw new IllegalArgumentException("Regular expression contains invalid symbol");
            }
        }
        if (nodes.size() > 1) {
            OperatorNode prev = new OperatorNode(Operator.SEQ);
            for (RegNode node : nodes) {
                prev.addNode(node);
            }
            return prev;
        } else if (nodes.size() == 1){
            return nodes.get(0);
        } else {
            throw new IllegalArgumentException("Empty String");
        }
    }


}
