import org.junit.Test;

import static org.junit.Assert.*;

/**
 * test class for regular expression class
 */
public class RegularExpression_Test {

    /**
     * test convert2NFA
     */
    @Test
    public void convert2NFA() {
        RegularExpression exp = new RegularExpression(RegularExpression.parseReg("a|b"));
        EpsilonNFA nfa = exp.convert2NFA();
        assertTrue(nfa.symbolSet.contains('a'));
        assertTrue(nfa.symbolSet.contains('b'));
    }

    /**
     * test isSymbol
     */
    @Test
    public void isSymbol() {
        assertTrue(RegularExpression.isSymbol('a'));
        assertTrue(RegularExpression.isSymbol('b'));
        assertTrue(RegularExpression.isSymbol('A'));
        assertTrue(RegularExpression.isSymbol('0'));
        assertFalse(RegularExpression.isSymbol('#'));
        assertFalse(RegularExpression.isSymbol('|'));
        assertFalse(RegularExpression.isSymbol('('));
    }

    /**
     * test parseReg
     */
    @Test
    public void parseReg() {

        try {
            RegularExpression.parseReg("|a");
            fail();
        } catch (IllegalArgumentException ignored) {

        }

        try {
            RegularExpression.parseReg("(abc");
            fail();
        } catch (IllegalArgumentException ignored) {

        }

        try {
            RegularExpression.parseReg("%^&&");
            fail();
        } catch (IllegalArgumentException ignored) {

        }

        try {
            RegularExpression.parseReg("*ab");
            fail();
        } catch (IllegalArgumentException ignored) {

        }

        try {
            RegularExpression.parseReg("+ab");
            fail();
        } catch (IllegalArgumentException ignored) {

        }

        try {
            RegularExpression.parseReg(" ");
            fail();
        } catch (IllegalArgumentException ignored) {

        }

        try {
            RegularExpression.parseReg("ab | c+ ");

        } catch (IllegalArgumentException ignored) {
            fail();
        }

        RegNode node = RegularExpression.parseReg("a | b");
        assertNotNull(node);
    }
}

