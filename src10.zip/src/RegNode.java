import java.util.ArrayList;

/**
 * a base abstract class for regex parser
 */
public abstract class RegNode {

    /**
     * convert the node to nfa
     * @return nfa
     */
    public abstract EpsilonNFA convert2NFA();
}
