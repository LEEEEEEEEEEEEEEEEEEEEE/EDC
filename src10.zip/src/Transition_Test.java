import static org.junit.Assert.*;

/**
 * test class for transition
 */
public class Transition_Test {

    /**
     * test getSymbol
     */
    @org.junit.Test
    public void getSymbol() {
        Transition t = new Transition('a', new State(true, true));
        assertEquals('a', t.getSymbol());
    }

    /**
     * test getNextState
     */
    @org.junit.Test
    public void getNextState() {
        State next = new State(false, false);
        Transition t = new Transition('d', next);
        assertEquals(next, t.getNextState());
    }
}